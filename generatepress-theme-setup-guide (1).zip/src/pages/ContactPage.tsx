import { useState } from 'react';
import { Mail, MessageCircle, Clock, Send } from 'lucide-react';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setSubmitted(true);
  };

  return (
    <main>
      {/* Hero */}
      <section className="py-16 bg-gradient-to-br from-ivory to-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-charcoal mb-4">
            Get in Touch
          </h1>
          <p className="text-lg text-charcoal/70 max-w-2xl mx-auto">
            Have a question, feedback, or just want to say hello? We'd love to hear from you!
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Contact Info */}
            <div className="lg:col-span-1">
              <h2 className="font-playfair text-2xl font-bold text-charcoal mb-6">
                Ways to Reach Us
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-dusty-rose/10 flex items-center justify-center shrink-0">
                    <Mail className="text-dusty-rose" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-charcoal mb-1">Email</h3>
                    <p className="text-charcoal/70 text-sm">
                      hello@stylebookhub.com
                    </p>
                    <p className="text-charcoal/50 text-xs mt-1">
                      Best for detailed inquiries
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center shrink-0">
                    <MessageCircle className="text-gold" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-charcoal mb-1">Social Media</h3>
                    <p className="text-charcoal/70 text-sm">
                      DM us on Pinterest or Instagram
                    </p>
                    <p className="text-charcoal/50 text-xs mt-1">
                      Quick questions welcome!
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-wellness/10 flex items-center justify-center shrink-0">
                    <Clock className="text-wellness" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-charcoal mb-1">Response Time</h3>
                    <p className="text-charcoal/70 text-sm">
                      We typically respond within 24-48 hours
                    </p>
                    <p className="text-charcoal/50 text-xs mt-1">
                      Mon-Fri, 9am-5pm EST
                    </p>
                  </div>
                </div>
              </div>

              {/* FAQ Quick Links */}
              <div className="mt-10 p-6 bg-ivory rounded-xl">
                <h3 className="font-playfair text-lg font-semibold text-charcoal mb-4">
                  Common Questions
                </h3>
                <ul className="space-y-3 text-sm">
                  <li>
                    <a href="#" className="text-charcoal/70 hover:text-dusty-rose transition-colors">
                      → How do I submit a guest post?
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-charcoal/70 hover:text-dusty-rose transition-colors">
                      → Can you feature my product?
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-charcoal/70 hover:text-dusty-rose transition-colors">
                      → How do I unsubscribe from emails?
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-charcoal/70 hover:text-dusty-rose transition-colors">
                      → Do you offer sponsored posts?
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              {submitted ? (
                <div className="bg-wellness/10 rounded-xl p-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-wellness/20 flex items-center justify-center mx-auto mb-4">
                    <Send className="text-wellness" size={28} />
                  </div>
                  <h2 className="font-playfair text-2xl font-bold text-charcoal mb-2">
                    Message Sent!
                  </h2>
                  <p className="text-charcoal/70 mb-6">
                    Thank you for reaching out. We'll get back to you within 24-48 hours.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({ name: '', email: '', subject: '', message: '' });
                    }}
                    className="text-dusty-rose font-medium hover:text-gold transition-colors"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <div className="bg-ivory rounded-xl p-8">
                  <h2 className="font-playfair text-2xl font-bold text-charcoal mb-6">
                    Send a Message
                  </h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-charcoal mb-2">
                          Your Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="w-full px-4 py-3 rounded-lg border border-charcoal/20 focus:outline-none focus:border-dusty-rose transition-colors bg-white"
                          placeholder="Jane Smith"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-charcoal mb-2">
                          Your Email *
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full px-4 py-3 rounded-lg border border-charcoal/20 focus:outline-none focus:border-dusty-rose transition-colors bg-white"
                          placeholder="jane@example.com"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-charcoal mb-2">
                        Subject *
                      </label>
                      <select
                        required
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-charcoal/20 focus:outline-none focus:border-dusty-rose transition-colors bg-white"
                      >
                        <option value="">Select a topic...</option>
                        <option value="general">General Question</option>
                        <option value="collaboration">Brand Collaboration</option>
                        <option value="feedback">Feedback or Suggestion</option>
                        <option value="technical">Technical Issue</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-charcoal mb-2">
                        Message *
                      </label>
                      <textarea
                        required
                        rows={6}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-charcoal/20 focus:outline-none focus:border-dusty-rose transition-colors bg-white resize-none"
                        placeholder="Tell us what's on your mind..."
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-dusty-rose text-white py-4 rounded-lg font-medium hover:bg-gold transition-colors flex items-center justify-center gap-2"
                    >
                      <Send size={18} />
                      Send Message
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default ContactPage;
