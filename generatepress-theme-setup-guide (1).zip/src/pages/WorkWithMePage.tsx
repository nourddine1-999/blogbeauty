import { Link } from 'react-router-dom';
import { Users, FileText, Camera, Star, ArrowRight, CheckCircle } from 'lucide-react';

const WorkWithMePage = () => {
  const services = [
    {
      icon: FileText,
      title: 'Sponsored Posts',
      description: 'Authentic, in-depth content featuring your product or service, seamlessly integrated into our editorial style.',
      features: ['In-depth product review', 'Pinterest-optimized graphics', 'Social media promotion', 'Permanent placement'],
    },
    {
      icon: Camera,
      title: 'Brand Ambassadorship',
      description: 'Long-term partnerships that build genuine connections between your brand and our engaged audience.',
      features: ['Multiple content pieces', 'Ongoing social features', 'Exclusive discount codes', 'Regular reporting'],
    },
    {
      icon: Users,
      title: 'Affiliate Partnerships',
      description: 'Performance-based collaborations where we authentically recommend products we love to our readers.',
      features: ['Commission-based model', 'Genuine recommendations', 'Integrated in relevant content', 'Track performance'],
    },
    {
      icon: Star,
      title: 'Product Reviews',
      description: 'Honest, detailed reviews that help our readers make informed purchasing decisions.',
      features: ['Hands-on testing', 'Pros and cons coverage', 'Comparison features', 'High-quality photos'],
    },
  ];

  const stats = [
    { label: 'Monthly Readers', value: '10K+' },
    { label: 'Pinterest Impressions', value: '50K+' },
    { label: 'Email Subscribers', value: '2.5K+' },
    { label: 'Avg. Post Views', value: '1.5K' },
  ];

  return (
    <main>
      {/* Hero */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-ivory via-white to-gold/10 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-72 h-72 bg-dusty-rose/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-64 h-64 bg-gold/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-4xl mx-auto px-4 relative text-center">
          <span className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full text-gold font-medium shadow-sm mb-6">
            <Star size={16} />
            Partner With Us
          </span>
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-charcoal mb-6">
            Let's Create Something <span className="text-dusty-rose">Beautiful</span> Together
          </h1>
          <p className="text-lg md:text-xl text-charcoal/70 max-w-2xl mx-auto mb-8">
            StyleBookHub partners with brands that align with our mission of helping readers live 
            stylish, organized, and intentional lives.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-dusty-rose text-white px-8 py-4 rounded-full font-medium hover:bg-gold transition-colors"
          >
            Start a Conversation
            <ArrowRight size={18} />
          </a>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-white border-b border-ivory">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="font-playfair text-3xl md:text-4xl font-bold text-dusty-rose mb-1">
                  {stat.value}
                </p>
                <p className="text-charcoal/60 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Partner */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-6">
                Why Partner With StyleBookHub?
              </h2>
              <p className="text-charcoal/70 mb-6 leading-relaxed">
                Our audience is highly engaged women aged 25-45 who are actively seeking ways to 
                improve their homes, beauty routines, wardrobes, and financial wellness.
              </p>
              <ul className="space-y-4">
                {[
                  'Authentic, storytelling-focused content that resonates',
                  'Pinterest-first strategy with evergreen traffic',
                  'Dedicated, engaged email subscriber base',
                  'Multiple niche coverage for cross-category campaigns',
                  'Professional photography and branded graphics',
                  'Transparent reporting and communication',
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle className="text-wellness shrink-0 mt-1" size={18} />
                    <span className="text-charcoal/80">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-ivory rounded-2xl p-8">
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-4">
                Our Audience
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-charcoal/70">Women</span>
                    <span className="text-charcoal font-medium">85%</span>
                  </div>
                  <div className="h-2 bg-charcoal/10 rounded-full overflow-hidden">
                    <div className="h-full bg-dusty-rose rounded-full" style={{ width: '85%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-charcoal/70">Ages 25-45</span>
                    <span className="text-charcoal font-medium">72%</span>
                  </div>
                  <div className="h-2 bg-charcoal/10 rounded-full overflow-hidden">
                    <div className="h-full bg-gold rounded-full" style={{ width: '72%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-charcoal/70">United States</span>
                    <span className="text-charcoal font-medium">68%</span>
                  </div>
                  <div className="h-2 bg-charcoal/10 rounded-full overflow-hidden">
                    <div className="h-full bg-wellness rounded-full" style={{ width: '68%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-charcoal/70">Engaged (Pinterest)</span>
                    <span className="text-charcoal font-medium">High</span>
                  </div>
                  <div className="h-2 bg-charcoal/10 rounded-full overflow-hidden">
                    <div className="h-full bg-home-decor rounded-full" style={{ width: '90%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 bg-ivory">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Partnership Opportunities
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              We offer flexible collaboration options to meet your brand's goals and budget.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {services.map((service) => (
              <div key={service.title} className="bg-white rounded-xl p-8 shadow-sm">
                <div className="w-14 h-14 rounded-xl bg-dusty-rose/10 flex items-center justify-center mb-6">
                  <service.icon className="text-dusty-rose" size={24} />
                </div>
                <h3 className="font-playfair text-xl font-semibold text-charcoal mb-3">
                  {service.title}
                </h3>
                <p className="text-charcoal/70 mb-4">
                  {service.description}
                </p>
                <ul className="space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-charcoal/60">
                      <div className="w-1.5 h-1.5 rounded-full bg-gold" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brands */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="font-playfair text-2xl font-bold text-charcoal mb-4">
            Brands We've Worked With
          </h2>
          <p className="text-charcoal/60 mb-8">
            We're proud to have partnered with brands that share our values.
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-50">
            {['Brand Co.', 'StyleHouse', 'BeautyLab', 'HomeNest', 'WellBeing', 'CraftStudio'].map((brand) => (
              <div key={brand} className="text-lg font-medium text-charcoal">
                {brand}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section id="contact" className="py-16 bg-gradient-to-r from-dusty-rose to-dusty-rose/80">
        <div className="max-w-4xl mx-auto px-4 text-center text-white">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Send us a message with your brand details, campaign goals, and budget range. 
            We'll get back to you within 48 hours with next steps.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 bg-white text-dusty-rose px-8 py-4 rounded-full font-medium hover:bg-ivory transition-colors"
            >
              Contact Us
              <ArrowRight size={18} />
            </Link>
            <a
              href="mailto:partnerships@stylebookhub.com"
              className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-medium hover:bg-white/10 transition-colors"
            >
              partnerships@stylebookhub.com
            </a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default WorkWithMePage;
