import { useParams, Link } from 'react-router-dom';
import { ChevronRight, Clock, User, Calendar, Bookmark, Share2 } from 'lucide-react';
import { getPostBySlug, getPostsByCategory } from '../data/posts';
import { getCategoryBySlug } from '../data/categories';
import PostCard from '../components/PostCard';

const PostPage = () => {
  const { slug } = useParams();
  const post = getPostBySlug(slug || '');
  
  if (!post) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="font-playfair text-3xl font-bold text-charcoal mb-4">
          Post Not Found
        </h1>
        <p className="text-charcoal/60 mb-8">
          The article you're looking for doesn't exist.
        </p>
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 bg-dusty-rose text-white px-6 py-3 rounded-full font-medium hover:bg-gold transition-colors"
        >
          Browse All Posts
        </Link>
      </div>
    );
  }

  const category = getCategoryBySlug(post.category);
  const relatedPosts = getPostsByCategory(post.category)
    .filter(p => p.id !== post.id)
    .slice(0, 3);

  const formattedDate = new Date(post.date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <main>
      {/* Post Header */}
      <section className="py-8 bg-ivory">
        <div className="max-w-4xl mx-auto px-4">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-charcoal/60 mb-6">
            <Link to="/" className="hover:text-dusty-rose transition-colors">Home</Link>
            <ChevronRight size={14} />
            <Link 
              to={`/category/${post.category}`}
              className="hover:text-dusty-rose transition-colors"
            >
              {category?.name}
            </Link>
            <ChevronRight size={14} />
            <span className="text-charcoal truncate max-w-[200px]">{post.title}</span>
          </nav>

          {/* Category Badge */}
          <Link
            to={`/category/${post.category}`}
            className="inline-block px-4 py-1 rounded-full text-sm font-semibold uppercase tracking-wider mb-4"
            style={{ backgroundColor: `${category?.color}20`, color: category?.color }}
          >
            {category?.name.split('&')[0].trim()}
          </Link>

          {/* Title */}
          <h1 className="font-playfair text-3xl md:text-5xl font-bold text-charcoal mb-6 leading-tight">
            {post.title}
          </h1>

          {/* Meta */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-charcoal/60 mb-6">
            <span className="flex items-center gap-2">
              <User size={16} />
              {post.author}
            </span>
            <span className="flex items-center gap-2">
              <Calendar size={16} />
              {formattedDate}
            </span>
            <span className="flex items-center gap-2">
              <Clock size={16} />
              {post.readTime} read
            </span>
          </div>

          {/* Share & Save */}
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-4 py-2 bg-dusty-rose text-white rounded-full text-sm font-medium hover:bg-gold transition-colors">
              <Bookmark size={16} />
              Save to Pinterest
            </button>
            <button className="p-2 rounded-full bg-white text-charcoal/60 hover:text-dusty-rose transition-colors">
              <Share2 size={18} />
            </button>
            <button className="p-2 rounded-full bg-white text-charcoal/60 hover:text-[#1877F2] transition-colors">
              <svg className="w-[18px] h-[18px]" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            </button>
            <button className="p-2 rounded-full bg-white text-charcoal/60 hover:text-[#1DA1F2] transition-colors">
              <svg className="w-[18px] h-[18px]" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
            </button>
          </div>
        </div>
      </section>

      {/* Featured Image */}
      <section className="max-w-5xl mx-auto px-4 -mt-0 md:-mt-0">
        <div className="rounded-2xl overflow-hidden shadow-lg">
          <img
            src={post.image}
            alt={post.title}
            className="w-full aspect-video object-cover"
          />
        </div>
      </section>

      {/* Post Content */}
      <article className="max-w-3xl mx-auto px-4 py-12">
        {/* Table of Contents */}
        <div className="bg-ivory rounded-xl p-6 mb-8">
          <h3 className="font-playfair text-lg font-semibold text-charcoal mb-4">
            📖 Table of Contents
          </h3>
          <ul className="space-y-2 text-charcoal/70">
            <li>
              <a href="#introduction" className="hover:text-dusty-rose transition-colors">
                1. Introduction
              </a>
            </li>
            <li>
              <a href="#main-tips" className="hover:text-dusty-rose transition-colors">
                2. Main Tips & Ideas
              </a>
            </li>
            <li>
              <a href="#implementation" className="hover:text-dusty-rose transition-colors">
                3. How to Implement
              </a>
            </li>
            <li>
              <a href="#conclusion" className="hover:text-dusty-rose transition-colors">
                4. Final Thoughts
              </a>
            </li>
          </ul>
        </div>

        {/* Content */}
        <div className="prose prose-lg max-w-none">
          <p className="text-lg text-charcoal/80 leading-relaxed mb-6">
            {post.excerpt}
          </p>

          <h2 id="introduction" className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Introduction
          </h2>
          <p className="text-charcoal/80 leading-relaxed mb-6">
            Welcome to this comprehensive guide! In this article, we'll explore everything you need to know 
            about {post.title.toLowerCase()}. Whether you're a beginner or looking to refine your skills, 
            you'll find valuable insights and practical tips to help you on your journey.
          </p>
          <p className="text-charcoal/80 leading-relaxed mb-6">
            Creating a beautiful and functional space doesn't have to be overwhelming or expensive. 
            With the right approach and some creativity, you can achieve stunning results that reflect 
            your personal style while staying within your budget.
          </p>

          {/* Quote Block */}
          <blockquote className="border-l-4 border-dusty-rose bg-dusty-rose/10 p-6 my-8 rounded-r-xl">
            <p className="font-playfair text-xl text-charcoal italic">
              "Style is a way to say who you are without having to speak."
            </p>
            <cite className="text-charcoal/60 text-sm mt-2 block">— Rachel Zoe</cite>
          </blockquote>

          <h2 id="main-tips" className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Main Tips & Ideas
          </h2>
          <p className="text-charcoal/80 leading-relaxed mb-6">
            Let's dive into the key strategies that will help you achieve your goals. These tips have been 
            carefully curated based on extensive research and real-world experience.
          </p>

          <ul className="list-disc list-inside space-y-3 text-charcoal/80 mb-6">
            <li>Start with a clear vision of what you want to achieve</li>
            <li>Focus on quality over quantity for lasting results</li>
            <li>Don't be afraid to experiment and try new things</li>
            <li>Take inspiration from multiple sources and make it your own</li>
            <li>Remember that progress, not perfection, is the goal</li>
          </ul>

          {/* Pinnable Image */}
          <div className="my-8 relative group">
            <img
              src={post.image}
              alt={`Pin this: ${post.title}`}
              className="w-full rounded-xl shadow-md"
            />
            <button className="absolute top-4 right-4 bg-dusty-rose text-white px-4 py-2 rounded-full text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2">
              <Bookmark size={16} />
              Pin It
            </button>
          </div>

          <h2 id="implementation" className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            How to Implement
          </h2>
          <p className="text-charcoal/80 leading-relaxed mb-6">
            Now that you understand the key concepts, let's talk about how to put them into practice. 
            Implementation is where the magic happens, so take your time and enjoy the process.
          </p>

          <ol className="list-decimal list-inside space-y-3 text-charcoal/80 mb-6">
            <li>Assess your current situation and identify areas for improvement</li>
            <li>Create a realistic timeline and set achievable milestones</li>
            <li>Gather the necessary resources and tools</li>
            <li>Start small and build momentum gradually</li>
            <li>Track your progress and celebrate small wins</li>
          </ol>

          <h2 id="conclusion" className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Final Thoughts
          </h2>
          <p className="text-charcoal/80 leading-relaxed mb-6">
            We hope this guide has provided you with valuable insights and inspiration. Remember, 
            the journey is just as important as the destination. Take what resonates with you and 
            adapt it to fit your unique circumstances and preferences.
          </p>
          <p className="text-charcoal/80 leading-relaxed">
            If you found this article helpful, don't forget to save it to Pinterest for future reference 
            and share it with friends who might benefit from these tips. Happy styling!
          </p>
        </div>

        {/* Tags */}
        <div className="mt-10 pt-8 border-t border-ivory">
          <h4 className="text-sm font-medium text-charcoal/60 mb-3">Tags:</h4>
          <div className="flex flex-wrap gap-2">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 bg-ivory text-charcoal/70 rounded-full text-sm"
              >
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Author Bio */}
        <div className="mt-10 bg-ivory rounded-xl p-6 flex flex-col md:flex-row gap-6 items-center md:items-start">
          <div className="w-20 h-20 rounded-full bg-dusty-rose flex items-center justify-center text-white text-2xl font-bold shrink-0">
            {post.author.charAt(0)}
          </div>
          <div className="text-center md:text-left">
            <h4 className="font-playfair text-xl font-semibold text-charcoal mb-2">
              {post.author}
            </h4>
            <p className="text-charcoal/70 text-sm mb-4">
              Passionate about helping others create beautiful, functional spaces and live their best lives. 
              When not writing, you can find me exploring thrift stores or experimenting with new DIY projects.
            </p>
            <Link
              to="/about"
              className="text-dusty-rose font-medium text-sm hover:text-gold transition-colors"
            >
              Learn more about me →
            </Link>
          </div>
        </div>
      </article>

      {/* Email Opt-in */}
      <section className="max-w-3xl mx-auto px-4 pb-12">
        <div className="bg-gradient-to-r from-dusty-rose to-dusty-rose/80 rounded-xl p-8 text-white text-center">
          <h3 className="font-playfair text-2xl font-bold mb-3">
            Enjoyed This Article?
          </h3>
          <p className="text-white/90 mb-6">
            Get more inspiration delivered to your inbox every week!
          </p>
          <form className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-1 px-6 py-3 rounded-full text-charcoal focus:outline-none"
            />
            <button
              type="submit"
              className="bg-gold text-white px-6 py-3 rounded-full font-medium hover:bg-charcoal transition-colors whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="py-12 bg-ivory">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="font-playfair text-2xl font-bold text-charcoal mb-8">
              You May Also Like
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {relatedPosts.map((relatedPost) => (
                <PostCard key={relatedPost.id} post={relatedPost} />
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
};

export default PostPage;
