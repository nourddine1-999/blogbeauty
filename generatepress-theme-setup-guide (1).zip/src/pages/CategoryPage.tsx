import { useParams, Link } from 'react-router-dom';
import { ChevronRight, ArrowRight } from 'lucide-react';
import { getCategoryBySlug, categories } from '../data/categories';
import { getPostsByCategory } from '../data/posts';
import PostCard from '../components/PostCard';

const CategoryPage = () => {
  const { categorySlug, subcategorySlug } = useParams();
  const category = getCategoryBySlug(categorySlug || '');
  const allPosts = getPostsByCategory(categorySlug || '');
  
  const posts = subcategorySlug 
    ? allPosts.filter(p => p.subcategory === subcategorySlug)
    : allPosts;

  const currentSubcategory = category?.subcategories.find(
    sub => sub.slug === subcategorySlug
  );

  if (!category) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="font-playfair text-3xl font-bold text-charcoal mb-4">
          Category Not Found
        </h1>
        <p className="text-charcoal/60 mb-8">
          The category you're looking for doesn't exist.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 bg-dusty-rose text-white px-6 py-3 rounded-full font-medium hover:bg-gold transition-colors"
        >
          Back to Home
        </Link>
      </div>
    );
  }

  return (
    <main>
      {/* Hero Section */}
      <section 
        className="py-16 md:py-20"
        style={{ backgroundColor: `${category.color}15` }}
      >
        <div className="max-w-7xl mx-auto px-4">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-charcoal/60 mb-6">
            <Link to="/" className="hover:text-dusty-rose transition-colors">Home</Link>
            <ChevronRight size={14} />
            <Link 
              to={`/category/${category.slug}`}
              className={subcategorySlug ? 'hover:text-dusty-rose transition-colors' : 'text-charcoal'}
            >
              {category.name}
            </Link>
            {currentSubcategory && (
              <>
                <ChevronRight size={14} />
                <span className="text-charcoal">{currentSubcategory.name}</span>
              </>
            )}
          </nav>

          <div className="flex flex-col md:flex-row md:items-center gap-6">
            <span className="text-6xl">{category.icon}</span>
            <div>
              <h1 className="font-playfair text-4xl md:text-5xl font-bold text-charcoal mb-3">
                {currentSubcategory ? currentSubcategory.name : category.name}
              </h1>
              <p className="text-charcoal/70 text-lg max-w-2xl">
                {category.description}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Subcategories */}
      {!subcategorySlug && (
        <section className="py-8 bg-white border-b border-ivory">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex flex-wrap gap-3">
              <Link
                to={`/category/${category.slug}`}
                className="px-4 py-2 rounded-full text-sm font-medium bg-charcoal text-white"
              >
                All
              </Link>
              {category.subcategories.map((sub) => (
                <Link
                  key={sub.slug}
                  to={`/category/${category.slug}/${sub.slug}`}
                  className="px-4 py-2 rounded-full text-sm font-medium bg-ivory text-charcoal hover:bg-dusty-rose hover:text-white transition-colors"
                >
                  {sub.name}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Posts Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          {posts.length > 0 ? (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
              
              {/* Load More */}
              <div className="text-center mt-12">
                <button className="inline-flex items-center gap-2 bg-charcoal text-white px-8 py-4 rounded-full font-medium hover:bg-dusty-rose transition-colors">
                  Load More Posts
                  <ArrowRight size={18} />
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <p className="text-charcoal/60 mb-4">No posts found in this category yet.</p>
              <Link
                to={`/category/${category.slug}`}
                className="text-dusty-rose hover:text-gold transition-colors"
              >
                Browse all {category.name} posts
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Related Categories */}
      <section className="py-12 bg-ivory">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="font-playfair text-2xl font-bold text-charcoal mb-6">
            Explore More Topics
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories
              .filter((c) => c.id !== category.id)
              .slice(0, 5)
              .map((cat) => (
                <Link
                  key={cat.id}
                  to={`/category/${cat.slug}`}
                  className="bg-white rounded-lg p-4 text-center hover:shadow-md transition-shadow"
                >
                  <span className="text-3xl mb-2 block">{cat.icon}</span>
                  <span className="text-sm font-medium text-charcoal">
                    {cat.name.split('&')[0].trim()}
                  </span>
                </Link>
              ))}
          </div>
        </div>
      </section>
    </main>
  );
};

export default CategoryPage;
