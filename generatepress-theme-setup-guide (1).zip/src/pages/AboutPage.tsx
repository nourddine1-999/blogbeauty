import { Link } from 'react-router-dom';
import { Heart, Target, Users, ArrowRight } from 'lucide-react';
import { categories } from '../data/categories';

const AboutPage = () => {
  return (
    <main>
      {/* Hero */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-ivory via-white to-dusty-rose/10 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-72 h-72 bg-dusty-rose/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-64 h-64 bg-gold/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-4xl mx-auto px-4 relative">
          <div className="text-center">
            <span className="inline-block px-4 py-2 bg-white rounded-full text-dusty-rose text-sm font-medium shadow-sm mb-6">
              👋 Nice to meet you!
            </span>
            <h1 className="font-playfair text-4xl md:text-6xl font-bold text-charcoal mb-6">
              Welcome to <span className="text-dusty-rose">StyleBookHub</span>
            </h1>
            <p className="text-lg md:text-xl text-charcoal/70 max-w-2xl mx-auto">
              We're on a mission to help you create a beautiful, organized, and fulfilling life — 
              without breaking the bank or burning out.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-6">
                Our Story
              </h2>
              <p className="text-charcoal/70 mb-4 leading-relaxed">
                StyleBookHub started as a passion project in 2024, born from the idea that living a 
                stylish life shouldn't require a massive budget or endless hours of research.
              </p>
              <p className="text-charcoal/70 mb-4 leading-relaxed">
                We noticed that most lifestyle content was scattered across different platforms — 
                home decor on one blog, beauty tips on another, financial advice somewhere else. 
                We wanted to create a single destination where everything connects.
              </p>
              <p className="text-charcoal/70 mb-6 leading-relaxed">
                Today, StyleBookHub serves thousands of readers who share our belief that beauty, 
                wellness, and practicality can coexist. Every article we publish is designed to 
                inspire action and deliver real results.
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-dusty-rose text-white flex items-center justify-center text-lg font-bold">
                  E
                </div>
                <div>
                  <p className="font-semibold text-charcoal">Emma Collins</p>
                  <p className="text-sm text-charcoal/60">Founder & Editor</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-xl">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80"
                  alt="StyleBookHub workspace"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-dusty-rose text-white p-6 rounded-xl shadow-lg">
                <p className="font-playfair text-3xl font-bold">10K+</p>
                <p className="text-white/80 text-sm">Monthly Readers</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-ivory">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              What We Believe In
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              These core values guide everything we create and share with our community.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 text-center shadow-sm">
              <div className="w-14 h-14 rounded-full bg-dusty-rose/10 flex items-center justify-center mx-auto mb-4">
                <Heart className="text-dusty-rose" size={24} />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-3">
                Authenticity First
              </h3>
              <p className="text-charcoal/70 text-sm">
                We only recommend products and ideas we genuinely believe in. 
                Our content is honest, relatable, and never pretentious.
              </p>
            </div>
            <div className="bg-white rounded-xl p-8 text-center shadow-sm">
              <div className="w-14 h-14 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4">
                <Target className="text-gold" size={24} />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-3">
                Practical Value
              </h3>
              <p className="text-charcoal/70 text-sm">
                Every article is designed to give you actionable takeaways. 
                We focus on what works, not just what looks good.
              </p>
            </div>
            <div className="bg-white rounded-xl p-8 text-center shadow-sm">
              <div className="w-14 h-14 rounded-full bg-home-decor/10 flex items-center justify-center mx-auto mb-4">
                <Users className="text-home-decor" size={24} />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-3">
                Community Connection
              </h3>
              <p className="text-charcoal/70 text-sm">
                Our readers are part of the family. We listen to your feedback 
                and create content that addresses your real needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              What We Cover
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              Six interconnected topics designed to help you live your best life.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/category/${category.slug}`}
                className="group bg-ivory rounded-xl p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-4">
                  <span className="text-3xl">{category.icon}</span>
                  <div>
                    <h3 className="font-playfair text-lg font-semibold text-charcoal mb-2 group-hover:text-dusty-rose transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-charcoal/60 text-sm line-clamp-2">
                      {category.description}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-dusty-rose to-dusty-rose/80">
        <div className="max-w-4xl mx-auto px-4 text-center text-white">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Your Journey?
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Whether you're redecorating your home, building a capsule wardrobe, or taking control 
            of your finances, we're here to help every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/start-here"
              className="inline-flex items-center justify-center gap-2 bg-white text-dusty-rose px-8 py-4 rounded-full font-medium hover:bg-ivory transition-colors"
            >
              Start Here Guide
              <ArrowRight size={18} />
            </Link>
            <Link
              to="/blog"
              className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-medium hover:bg-white/10 transition-colors"
            >
              Browse Articles
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 bg-ivory">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="font-playfair text-2xl font-bold text-charcoal mb-4">
            Get in Touch
          </h2>
          <p className="text-charcoal/70 mb-6">
            Have questions, feedback, or collaboration ideas? We'd love to hear from you!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 bg-charcoal text-white px-6 py-3 rounded-full font-medium hover:bg-dusty-rose transition-colors"
            >
              Contact Us
            </Link>
            <Link
              to="/work-with-me"
              className="inline-flex items-center justify-center gap-2 bg-white text-charcoal px-6 py-3 rounded-full font-medium hover:bg-dusty-rose hover:text-white transition-colors border border-charcoal/20"
            >
              Work With Me
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
};

export default AboutPage;
