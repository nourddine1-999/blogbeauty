import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Sparkles, Target, Compass } from 'lucide-react';
import { categories } from '../data/categories';
import { posts } from '../data/posts';

const StartHerePage = () => {
  const featuredPosts = posts.filter(p => p.featured);

  return (
    <main>
      {/* Hero */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-ivory via-white to-gold/10 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-20 w-64 h-64 bg-dusty-rose/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gold/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-4xl mx-auto px-4 relative text-center">
          <span className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full text-gold font-medium shadow-sm mb-6">
            <Compass size={16} />
            Your Starting Point
          </span>
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-charcoal mb-6">
            Welcome to <span className="text-dusty-rose">StyleBookHub!</span>
          </h1>
          <p className="text-lg md:text-xl text-charcoal/70 max-w-2xl mx-auto mb-8">
            New here? This guide will help you navigate our content and find exactly what you need 
            to start living a more stylish, organized, and intentional life.
          </p>
          <div className="flex justify-center gap-3">
            <span className="w-3 h-3 rounded-full bg-dusty-rose"></span>
            <span className="w-3 h-3 rounded-full bg-gold"></span>
            <span className="w-3 h-3 rounded-full bg-home-decor"></span>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              How StyleBookHub Works
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              We've organized our content into six interconnected topics to help you find what you need quickly.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-dusty-rose/10 flex items-center justify-center mx-auto mb-4">
                <BookOpen className="text-dusty-rose" size={28} />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-2">
                1. Browse Categories
              </h3>
              <p className="text-charcoal/70">
                Explore topics that interest you — from home decor to personal finance. Each category 
                has subcategories for deeper dives.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="text-gold" size={28} />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-2">
                2. Save Your Favorites
              </h3>
              <p className="text-charcoal/70">
                Pin articles to Pinterest or bookmark them for later. We create Pinterest-optimized 
                graphics for easy saving.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-wellness/10 flex items-center justify-center mx-auto mb-4">
                <Target className="text-wellness" size={28} />
              </div>
              <h3 className="font-playfair text-xl font-semibold text-charcoal mb-2">
                3. Take Action
              </h3>
              <p className="text-charcoal/70">
                Every article includes practical tips you can implement right away. Start small and 
                build momentum over time.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Breakdown */}
      <section className="py-16 bg-ivory">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Explore Our Topics
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              Click on any category to start exploring. Each one is designed to help you improve 
              a different area of your life.
            </p>
          </div>
          <div className="space-y-6">
            {categories.map((category, index) => (
              <Link
                key={category.id}
                to={`/category/${category.slug}`}
                className="group block bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex flex-col md:flex-row md:items-center gap-6">
                  <div 
                    className="w-16 h-16 rounded-xl flex items-center justify-center text-3xl shrink-0"
                    style={{ backgroundColor: `${category.color}20` }}
                  >
                    {category.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-charcoal/40 uppercase tracking-wider">
                        Category {index + 1}
                      </span>
                    </div>
                    <h3 className="font-playfair text-xl font-semibold text-charcoal mb-2 group-hover:text-dusty-rose transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-charcoal/70 text-sm mb-3">
                      {category.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {category.subcategories.slice(0, 4).map((sub) => (
                        <span 
                          key={sub.slug}
                          className="text-xs px-3 py-1 rounded-full bg-ivory text-charcoal/60"
                        >
                          {sub.name}
                        </span>
                      ))}
                      {category.subcategories.length > 4 && (
                        <span className="text-xs px-3 py-1 rounded-full bg-ivory text-charcoal/60">
                          +{category.subcategories.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>
                  <ArrowRight 
                    size={24} 
                    className="text-charcoal/30 group-hover:text-dusty-rose group-hover:translate-x-2 transition-all shrink-0" 
                  />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Recommended Reading */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Recommended Reading
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              Not sure where to start? Here are some of our most popular articles across all categories.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredPosts.map((post) => {
              const category = categories.find(c => c.slug === post.category);
              return (
                <Link
                  key={post.id}
                  to={`/post/${post.slug}`}
                  className="group bg-ivory rounded-xl overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-5">
                    <span 
                      className="text-xs font-semibold uppercase tracking-wider"
                      style={{ color: category?.color }}
                    >
                      {category?.icon} {category?.name.split('&')[0].trim()}
                    </span>
                    <h3 className="font-playfair text-lg font-semibold text-charcoal mt-2 group-hover:text-dusty-rose transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                  </div>
                </Link>
              );
            })}
          </div>
          <div className="text-center mt-10">
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 bg-charcoal text-white px-8 py-4 rounded-full font-medium hover:bg-dusty-rose transition-colors"
            >
              View All Articles
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Connect Section */}
      <section className="py-16 bg-gradient-to-r from-dusty-rose to-dusty-rose/80">
        <div className="max-w-4xl mx-auto px-4 text-center text-white">
          <h2 className="font-playfair text-3xl md:text-4xl font-bold mb-4">
            Let's Stay Connected!
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Follow us on Pinterest for daily inspiration, join our email list for exclusive content, 
            or reach out if you have questions!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#"
              className="inline-flex items-center justify-center gap-2 bg-white text-dusty-rose px-8 py-4 rounded-full font-medium hover:bg-ivory transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>
              Follow on Pinterest
            </a>
            <Link
              to="/about"
              className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-medium hover:bg-white/10 transition-colors"
            >
              Learn More About Us
            </Link>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-ivory">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <h2 className="font-playfair text-2xl md:text-3xl font-bold text-charcoal mb-4">
              Join The StyleBook Weekly
            </h2>
            <p className="text-charcoal/70 mb-6">
              Get our best content delivered straight to your inbox, plus a free printable mood board!
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-4 rounded-full border border-charcoal/20 focus:outline-none focus:border-dusty-rose transition-colors"
              />
              <button
                type="submit"
                className="bg-dusty-rose text-white px-8 py-4 rounded-full font-medium hover:bg-gold transition-colors whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </main>
  );
};

export default StartHerePage;
