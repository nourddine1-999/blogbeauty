const DisclaimerPage = () => {
  return (
    <main className="py-16 bg-white">
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="font-playfair text-4xl font-bold text-charcoal mb-4">
          Disclaimer
        </h1>
        <p className="text-charcoal/60 mb-8">
          Last updated: January 2024
        </p>

        <div className="prose prose-lg max-w-none text-charcoal/80">
          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-6 mb-4">
            General Disclaimer
          </h2>
          <p>
            The information provided on StyleBookHub is for general informational and educational 
            purposes only. All information on the site is provided in good faith; however, we make 
            no representation or warranty of any kind, express or implied, regarding the accuracy, 
            adequacy, validity, reliability, availability, or completeness of any information on the site.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Affiliate Disclosure
          </h2>
          <p>
            StyleBookHub is a participant in various affiliate advertising programs designed to provide 
            a means for sites to earn advertising fees by advertising and linking to partner websites.
          </p>
          <p>
            This means that when you click on certain links on our site and make a purchase, we may 
            receive a small commission at no additional cost to you. This helps support our website 
            and allows us to continue providing valuable content.
          </p>
          <p>
            <strong>Affiliate programs we participate in include:</strong>
          </p>
          <ul className="list-disc list-inside space-y-2 my-4">
            <li>Amazon Associates Program</li>
            <li>LTK (LikeToKnowIt)</li>
            <li>ShareASale</li>
            <li>Various brand affiliate programs</li>
          </ul>
          <p>
            We only recommend products and services that we genuinely believe in and think will 
            provide value to our readers. Our recommendations are based on our honest opinions 
            and experiences.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Sponsored Content
          </h2>
          <p>
            From time to time, we may publish sponsored content or work with brands on collaborative 
            projects. All sponsored content is clearly disclosed within the post. Despite compensation, 
            our opinions remain our own and are not influenced by sponsors.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Professional Advice Disclaimer
          </h2>
          <p>
            The content on StyleBookHub should not be considered professional advice:
          </p>
          <ul className="list-disc list-inside space-y-2 my-4">
            <li><strong>Financial Content:</strong> Information about budgeting, saving, and personal finance is for educational purposes only and should not be considered financial advice. Please consult a qualified financial advisor for personalized guidance.</li>
            <li><strong>Beauty & Skincare:</strong> Our skincare and beauty tips are based on personal experience and general information. Always patch test new products and consult a dermatologist for specific skin concerns.</li>
            <li><strong>Wellness Content:</strong> Our wellness and mental health content is not a substitute for professional medical advice. Please consult healthcare professionals for medical concerns.</li>
          </ul>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            External Links
          </h2>
          <p>
            Our website may contain links to external websites that are not operated by us. We have 
            no control over the content and practices of these sites and cannot accept responsibility 
            for their respective privacy policies.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Fair Use & Copyright
          </h2>
          <p>
            All content on StyleBookHub, including text, images, and graphics, is owned by StyleBookHub 
            unless otherwise noted. You may share our content on social media with proper attribution 
            and a link back to the original post. Reproduction of content without permission is prohibited.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Contact
          </h2>
          <p>
            If you have any questions about this disclaimer, please contact us at 
            hello@stylebookhub.com.
          </p>
        </div>
      </div>
    </main>
  );
};

export default DisclaimerPage;
