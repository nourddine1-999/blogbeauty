import { useState } from 'react';
import { ArrowRight, Grid, List } from 'lucide-react';
import { posts } from '../data/posts';
import { categories } from '../data/categories';
import PostCard from '../components/PostCard';

const BlogPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredPosts = activeCategory === 'all' 
    ? posts 
    : posts.filter(p => p.category === activeCategory);

  return (
    <main>
      {/* Hero */}
      <section className="py-12 md:py-16 bg-gradient-to-br from-ivory to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="font-playfair text-4xl md:text-5xl font-bold text-charcoal mb-4">
              The Blog
            </h1>
            <p className="text-lg text-charcoal/70">
              Explore all our articles across home decor, beauty, fashion, wellness, 
              personal finance, and DIY projects. Find inspiration for every aspect of your life.
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-[73px] z-40 bg-white border-b border-ivory py-4">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setActiveCategory('all')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeCategory === 'all'
                    ? 'bg-charcoal text-white'
                    : 'bg-ivory text-charcoal hover:bg-dusty-rose hover:text-white'
                }`}
              >
                All Posts
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.slug)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    activeCategory === cat.slug
                      ? 'text-white'
                      : 'bg-ivory text-charcoal hover:bg-dusty-rose hover:text-white'
                  }`}
                  style={activeCategory === cat.slug ? { backgroundColor: cat.color } : {}}
                >
                  {cat.icon} {cat.name.split('&')[0].trim()}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-charcoal/60">View:</span>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-dusty-rose text-white' : 'text-charcoal/60 hover:text-charcoal'}`}
              >
                <Grid size={18} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-dusty-rose text-white' : 'text-charcoal/60 hover:text-charcoal'}`}
              >
                <List size={18} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Posts */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-6 flex items-center justify-between">
            <p className="text-charcoal/60">
              Showing {filteredPosts.length} article{filteredPosts.length !== 1 ? 's' : ''}
            </p>
          </div>

          {viewMode === 'grid' ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPosts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {filteredPosts.map((post) => (
                <PostCard key={post.id} post={post} variant="horizontal" />
              ))}
            </div>
          )}

          {filteredPosts.length > 0 && (
            <div className="text-center mt-12">
              <button className="inline-flex items-center gap-2 bg-charcoal text-white px-8 py-4 rounded-full font-medium hover:bg-dusty-rose transition-colors">
                Load More Posts
                <ArrowRight size={18} />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16 bg-dusty-rose">
        <div className="max-w-3xl mx-auto px-4 text-center text-white">
          <h2 className="font-playfair text-3xl font-bold mb-4">
            Never Miss a Post
          </h2>
          <p className="text-white/90 mb-6">
            Subscribe to get our latest articles delivered straight to your inbox.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-1 px-6 py-4 rounded-full text-charcoal focus:outline-none"
            />
            <button
              type="submit"
              className="bg-gold text-white px-8 py-4 rounded-full font-medium hover:bg-charcoal transition-colors whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>
    </main>
  );
};

export default BlogPage;
