const PrivacyPage = () => {
  return (
    <main className="py-16 bg-white">
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="font-playfair text-4xl font-bold text-charcoal mb-4">
          Privacy Policy
        </h1>
        <p className="text-charcoal/60 mb-8">
          Last updated: January 2024
        </p>

        <div className="prose prose-lg max-w-none text-charcoal/80">
          <p>
            StyleBookHub ("we," "our," or "us") is committed to protecting your privacy. This Privacy 
            Policy explains how we collect, use, and safeguard your information when you visit our website.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Information We Collect
          </h2>
          <p>We may collect information about you in a variety of ways:</p>
          <ul className="list-disc list-inside space-y-2 my-4">
            <li><strong>Personal Data:</strong> Name, email address, and other information you voluntarily provide when subscribing to our newsletter or contacting us.</li>
            <li><strong>Usage Data:</strong> Information about how you use our website, including pages visited, time spent, and referring sources.</li>
            <li><strong>Cookies:</strong> We use cookies and similar tracking technologies to enhance your experience.</li>
          </ul>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            How We Use Your Information
          </h2>
          <p>We use the information we collect to:</p>
          <ul className="list-disc list-inside space-y-2 my-4">
            <li>Send you newsletters and updates (if you've subscribed)</li>
            <li>Respond to your comments and questions</li>
            <li>Improve our website and content</li>
            <li>Analyze usage patterns to enhance user experience</li>
            <li>Comply with legal obligations</li>
          </ul>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Third-Party Services
          </h2>
          <p>
            We may use third-party services that collect, monitor, and analyze user data. These include:
          </p>
          <ul className="list-disc list-inside space-y-2 my-4">
            <li>Google Analytics for website analytics</li>
            <li>Email marketing platforms (e.g., ConvertKit, Mailchimp)</li>
            <li>Advertising networks</li>
            <li>Social media platforms (Pinterest, Instagram)</li>
          </ul>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Cookies
          </h2>
          <p>
            We use cookies to personalize content, analyze traffic, and improve your experience. 
            You can instruct your browser to refuse all cookies or indicate when a cookie is being sent.
          </p>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Your Rights
          </h2>
          <p>You have the right to:</p>
          <ul className="list-disc list-inside space-y-2 my-4">
            <li>Access the personal information we have about you</li>
            <li>Request correction of inaccurate information</li>
            <li>Request deletion of your personal information</li>
            <li>Unsubscribe from our email list at any time</li>
          </ul>

          <h2 className="font-playfair text-2xl font-bold text-charcoal mt-10 mb-4">
            Contact Us
          </h2>
          <p>
            If you have questions about this Privacy Policy, please contact us at 
            privacy@stylebookhub.com.
          </p>
        </div>
      </div>
    </main>
  );
};

export default PrivacyPage;
