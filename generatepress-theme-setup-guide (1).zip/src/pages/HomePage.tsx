import { ArrowRight, Mail, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { categories } from '../data/categories';
import { posts, getPostsByCategory, getLatestPosts } from '../data/posts';
import CategoryCard from '../components/CategoryCard';
import PostCard from '../components/PostCard';

const HomePage = () => {
  const featuredPosts = posts.filter((p) => p.featured).slice(0, 3);
  const latestPosts = getLatestPosts(6);

  return (
    <main>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-ivory via-white to-dusty-rose/10 py-16 md:py-24">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-dusty-rose/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="max-w-3xl mx-auto text-center">
            <span className="inline-flex items-center gap-2 bg-white px-4 py-2 rounded-full text-sm text-dusty-rose font-medium shadow-sm mb-6">
              <Sparkles size={16} />
              Welcome to StyleBookHub
            </span>
            <h1 className="font-playfair text-4xl md:text-6xl font-bold text-charcoal mb-6 leading-tight">
              Where Style Meets <span className="text-dusty-rose">Real Life</span>
            </h1>
            <p className="text-lg md:text-xl text-charcoal/70 mb-8 max-w-2xl mx-auto">
              Your destination for home decor inspiration, beauty tips, fashion ideas, wellness routines, 
              money-saving strategies, and creative DIY projects — all in one stylish place.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/start-here"
                className="inline-flex items-center justify-center gap-2 bg-dusty-rose text-white px-8 py-4 rounded-full font-medium hover:bg-gold transition-colors"
              >
                Start Exploring
                <ArrowRight size={18} />
              </Link>
              <Link
                to="/about"
                className="inline-flex items-center justify-center gap-2 bg-white text-charcoal px-8 py-4 rounded-full font-medium hover:bg-ivory transition-colors border border-charcoal/10"
              >
                About Us
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Explore Our Categories
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              Dive into six interconnected niches designed to help you live a more stylish, 
              organized, and fulfilling life — no matter your budget.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-16 bg-ivory">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-2">
                Featured Stories
              </h2>
              <p className="text-charcoal/60">Hand-picked articles our readers love</p>
            </div>
            <Link
              to="/blog"
              className="hidden md:flex items-center gap-2 text-dusty-rose font-medium hover:text-gold transition-colors"
            >
              View All Posts
              <ArrowRight size={18} />
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredPosts.map((post) => (
              <PostCard key={post.id} post={post} variant="featured" />
            ))}
          </div>
        </div>
      </section>

      {/* Latest Posts Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Latest from the Blog
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              Fresh inspiration, tips, and ideas published weekly
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestPosts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
          <div className="text-center mt-10">
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 bg-charcoal text-white px-8 py-4 rounded-full font-medium hover:bg-dusty-rose transition-colors"
            >
              Browse All Articles
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Niche-Specific Sections */}
      {categories.slice(0, 3).map((category) => {
        const categoryPosts = getPostsByCategory(category.slug).slice(0, 3);
        return (
          <section 
            key={category.id} 
            className="py-16"
            style={{ backgroundColor: `${category.color}10` }}
          >
            <div className="max-w-7xl mx-auto px-4">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{category.icon}</span>
                  <div>
                    <h2 className="font-playfair text-2xl font-bold text-charcoal">
                      From {category.name.split('&')[0].trim()}
                    </h2>
                    <p className="text-charcoal/60 text-sm">Latest articles and inspiration</p>
                  </div>
                </div>
                <Link
                  to={`/category/${category.slug}`}
                  className="flex items-center gap-2 font-medium transition-colors"
                  style={{ color: category.color }}
                >
                  See All
                  <ArrowRight size={18} />
                </Link>
              </div>
              <div className="grid md:grid-cols-3 gap-6">
                {categoryPosts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            </div>
          </section>
        );
      })}

      {/* Pinterest Banner */}
      <section className="py-16 bg-gradient-to-r from-dusty-rose to-dusty-rose/80">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-white text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>
                <h2 className="font-playfair text-3xl font-bold">Follow Us on Pinterest</h2>
              </div>
              <p className="text-white/90 text-lg max-w-md">
                Get daily inspiration, outfit ideas, home decor tips, and more delivered straight to your Pinterest feed.
              </p>
            </div>
            <a
              href="#"
              className="inline-flex items-center gap-2 bg-white text-dusty-rose px-8 py-4 rounded-full font-medium hover:bg-ivory transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>
              Follow @StyleBookHub
            </a>
          </div>
        </div>
      </section>

      {/* Email Opt-in Section */}
      <section className="py-20 bg-ivory">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            <div className="w-16 h-16 bg-dusty-rose/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Mail size={28} className="text-dusty-rose" />
            </div>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Get The StyleBook Weekly
            </h2>
            <p className="text-charcoal/70 mb-8 max-w-md mx-auto">
              Join 10,000+ subscribers and receive weekly inspiration, exclusive tips, 
              and a free home decor mood board printable!
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-4 rounded-full border border-charcoal/20 focus:outline-none focus:border-dusty-rose transition-colors"
              />
              <button
                type="submit"
                className="bg-dusty-rose text-white px-8 py-4 rounded-full font-medium hover:bg-gold transition-colors whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
            <p className="text-xs text-charcoal/50 mt-4">
              No spam, ever. Unsubscribe anytime.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
};

export default HomePage;
