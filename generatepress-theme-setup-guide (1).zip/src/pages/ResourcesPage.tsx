import { Link } from 'react-router-dom';
import { ExternalLink, Star, Download, ArrowRight } from 'lucide-react';

interface Resource {
  id: string;
  name: string;
  description: string;
  category: string;
  type: 'tool' | 'product' | 'service';
  link?: string;
  featured?: boolean;
}

const resources: Resource[] = [
  // Home Decor
  {
    id: '1',
    name: 'Wayfair',
    description: 'Affordable furniture and home decor with fast shipping. Great for budget-friendly room makeovers.',
    category: 'Home Decor',
    type: 'product',
    link: '#',
    featured: true,
  },
  {
    id: '2',
    name: 'Canva',
    description: 'Create mood boards, room layouts, and Pinterest graphics. Free and easy to use.',
    category: 'Home Decor',
    type: 'tool',
    link: '#',
  },
  // Beauty
  {
    id: '3',
    name: 'Sephora',
    description: 'Premium beauty products with excellent rewards program and free samples.',
    category: 'Beauty',
    type: 'product',
    featured: true,
  },
  {
    id: '4',
    name: 'Paula\'s Choice',
    description: 'Science-backed skincare products. Known for their BHA exfoliant.',
    category: 'Beauty',
    type: 'product',
  },
  // Fashion
  {
    id: '5',
    name: 'LTK (LikeToKnowIt)',
    description: 'Shop curated fashion looks and discover new styles from creators.',
    category: 'Fashion',
    type: 'tool',
    featured: true,
  },
  {
    id: '6',
    name: 'ThredUp',
    description: 'Secondhand clothing marketplace for sustainable fashion shopping.',
    category: 'Fashion',
    type: 'product',
  },
  // Wellness
  {
    id: '7',
    name: 'Headspace',
    description: 'Meditation and mindfulness app for daily mental wellness practice.',
    category: 'Wellness',
    type: 'service',
    featured: true,
  },
  {
    id: '8',
    name: 'Day One Journal',
    description: 'Beautiful journaling app for daily reflection and gratitude practice.',
    category: 'Wellness',
    type: 'tool',
  },
  // Finance
  {
    id: '9',
    name: 'YNAB (You Need A Budget)',
    description: 'The gold standard for budgeting apps. Changes how you think about money.',
    category: 'Finance',
    type: 'tool',
    featured: true,
  },
  {
    id: '10',
    name: 'Rakuten',
    description: 'Cash back on online shopping. Free money on purchases you\'d make anyway.',
    category: 'Finance',
    type: 'service',
  },
  // DIY
  {
    id: '11',
    name: 'Amazon',
    description: 'Craft supplies, tools, and materials for all your DIY projects.',
    category: 'DIY',
    type: 'product',
  },
  {
    id: '12',
    name: 'Cricut',
    description: 'Cutting machines for professional-looking DIY projects and crafts.',
    category: 'DIY',
    type: 'product',
    featured: true,
  },
];

const freebies = [
  {
    id: '1',
    title: 'Home Decor Mood Board Printable',
    description: '10-page PDF to help you plan your perfect space',
    category: 'Home Decor',
  },
  {
    id: '2',
    title: 'Skincare Routine Tracker',
    description: 'Track your products and results for 30 days',
    category: 'Beauty',
  },
  {
    id: '3',
    title: 'Capsule Wardrobe Checklist',
    description: 'Essential pieces for a versatile wardrobe',
    category: 'Fashion',
  },
  {
    id: '4',
    title: 'Weekly Budget Planner',
    description: 'Simple printable to track income and expenses',
    category: 'Finance',
  },
];

const categoryColors: Record<string, string> = {
  'Home Decor': '#8B7355',
  'Beauty': '#E8B4B8',
  'Fashion': '#9B8AA5',
  'Wellness': '#7FB3A8',
  'Finance': '#6B8E7A',
  'DIY': '#D4A574',
};

const ResourcesPage = () => {
  const categories = [...new Set(resources.map(r => r.category))];
  const featuredResources = resources.filter(r => r.featured);

  return (
    <main>
      {/* Hero */}
      <section className="py-16 md:py-20 bg-gradient-to-br from-ivory to-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-charcoal mb-4">
            Resources & Tools
          </h1>
          <p className="text-lg text-charcoal/70 max-w-2xl mx-auto">
            Our curated collection of favorite products, tools, and services to help you on your 
            journey to a more stylish and organized life.
          </p>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="bg-dusty-rose/10 py-4">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-sm text-charcoal/70">
            <strong>Disclosure:</strong> Some links on this page are affiliate links. We may earn a 
            commission if you make a purchase, at no extra cost to you. We only recommend products we genuinely love.
          </p>
        </div>
      </section>

      {/* Featured Resources */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center gap-3 mb-8">
            <Star className="text-gold" fill="currentColor" size={24} />
            <h2 className="font-playfair text-2xl font-bold text-charcoal">
              Editor's Picks
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredResources.map((resource) => (
              <a
                key={resource.id}
                href={resource.link || '#'}
                className="group bg-ivory rounded-xl p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <span 
                    className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full"
                    style={{ 
                      backgroundColor: `${categoryColors[resource.category]}20`,
                      color: categoryColors[resource.category]
                    }}
                  >
                    {resource.category}
                  </span>
                  <ExternalLink size={16} className="text-charcoal/40 group-hover:text-dusty-rose transition-colors" />
                </div>
                <h3 className="font-playfair text-lg font-semibold text-charcoal mb-2 group-hover:text-dusty-rose transition-colors">
                  {resource.name}
                </h3>
                <p className="text-charcoal/70 text-sm">
                  {resource.description}
                </p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* All Resources by Category */}
      <section className="py-16 bg-ivory">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="font-playfair text-3xl font-bold text-charcoal mb-12 text-center">
            Resources by Category
          </h2>
          <div className="space-y-12">
            {categories.map((category) => {
              const categoryResources = resources.filter(r => r.category === category);
              return (
                <div key={category}>
                  <div className="flex items-center gap-3 mb-6">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: categoryColors[category] }}
                    >
                      {category.charAt(0)}
                    </div>
                    <h3 className="font-playfair text-xl font-semibold text-charcoal">
                      {category}
                    </h3>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    {categoryResources.map((resource) => (
                      <a
                        key={resource.id}
                        href={resource.link || '#'}
                        className="group flex items-start gap-4 bg-white rounded-lg p-5 hover:shadow-sm transition-shadow"
                      >
                        <div className="flex-1">
                          <h4 className="font-medium text-charcoal mb-1 group-hover:text-dusty-rose transition-colors">
                            {resource.name}
                          </h4>
                          <p className="text-sm text-charcoal/60">
                            {resource.description}
                          </p>
                        </div>
                        <ExternalLink size={16} className="text-charcoal/30 group-hover:text-dusty-rose transition-colors shrink-0 mt-1" />
                      </a>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Free Downloads */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-gold/10 px-4 py-2 rounded-full text-gold font-medium mb-4">
              <Download size={18} />
              Free Downloads
            </div>
            <h2 className="font-playfair text-3xl font-bold text-charcoal mb-4">
              Free Printables & Guides
            </h2>
            <p className="text-charcoal/60 max-w-2xl mx-auto">
              Grab these free resources to help you get organized and stay on track.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {freebies.map((freebie) => (
              <div
                key={freebie.id}
                className="bg-ivory rounded-xl p-6 text-center"
              >
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
                  style={{ backgroundColor: `${categoryColors[freebie.category]}20` }}
                >
                  <Download size={20} style={{ color: categoryColors[freebie.category] }} />
                </div>
                <h3 className="font-playfair text-lg font-semibold text-charcoal mb-2">
                  {freebie.title}
                </h3>
                <p className="text-charcoal/60 text-sm mb-4">
                  {freebie.description}
                </p>
                <button className="text-dusty-rose font-medium text-sm hover:text-gold transition-colors">
                  Download Free →
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16 bg-gradient-to-r from-dusty-rose to-dusty-rose/80">
        <div className="max-w-4xl mx-auto px-4 text-center text-white">
          <h2 className="font-playfair text-3xl font-bold mb-4">
            Want More Recommendations?
          </h2>
          <p className="text-white/90 mb-8 max-w-2xl mx-auto">
            Subscribe to get exclusive deals, new product reviews, and curated recommendations 
            delivered to your inbox.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-6 py-4 rounded-full text-charcoal focus:outline-none"
            />
            <button
              type="submit"
              className="bg-gold text-white px-8 py-4 rounded-full font-medium hover:bg-charcoal transition-colors whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>

      {/* Work With Me */}
      <section className="py-16 bg-ivory">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="font-playfair text-2xl font-bold text-charcoal mb-4">
            Are You a Brand?
          </h2>
          <p className="text-charcoal/70 mb-6">
            Interested in partnering with StyleBookHub? We'd love to hear from you!
          </p>
          <Link
            to="/work-with-me"
            className="inline-flex items-center gap-2 bg-charcoal text-white px-8 py-4 rounded-full font-medium hover:bg-dusty-rose transition-colors"
          >
            Work With Me
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </main>
  );
};

export default ResourcesPage;
