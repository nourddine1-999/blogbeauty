import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search, ChevronDown } from 'lucide-react';
import { categories } from '../data/categories';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
    setActiveDropdown(null);
  }, [location]);

  return (
    <>
      {/* Top Bar */}
      <div className="bg-ivory text-charcoal text-sm py-2 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-dusty-rose transition-colors flex items-center gap-1">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146 1.124.347 2.317.535 3.554.535 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>
              Pinterest
            </a>
            <a href="#" className="hover:text-dusty-rose transition-colors flex items-center gap-1">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
              Instagram
            </a>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/start-here" className="hover:text-dusty-rose transition-colors font-medium">
              Start Here
            </Link>
            <button className="hover:text-dusty-rose transition-colors">
              <Search size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header 
        className={`sticky top-0 z-50 bg-white transition-shadow duration-300 ${
          isScrolled ? 'shadow-md' : ''
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          {/* Logo */}
          <div className="flex justify-center py-4 border-b border-ivory">
            <Link to="/" className="text-center">
              <h1 className="font-playfair text-3xl md:text-4xl font-bold text-charcoal">
                StyleBook<span className="text-dusty-rose">Hub</span>
              </h1>
              <p className="text-xs tracking-widest text-charcoal/60 uppercase mt-1">
                Where Style Meets Real Life
              </p>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex justify-center items-center py-3 gap-1">
            <Link 
              to="/" 
              className="px-4 py-2 text-charcoal hover:text-dusty-rose transition-colors font-medium"
            >
              Home
            </Link>
            
            {categories.map((category) => (
              <div 
                key={category.id}
                className="relative"
                onMouseEnter={() => setActiveDropdown(category.id)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  to={`/category/${category.slug}`}
                  className="px-4 py-2 text-charcoal hover:text-dusty-rose transition-colors font-medium flex items-center gap-1"
                >
                  {category.name.split(' ')[0]}
                  <ChevronDown size={14} className={`transition-transform ${activeDropdown === category.id ? 'rotate-180' : ''}`} />
                </Link>
                
                {activeDropdown === category.id && (
                  <div className="absolute top-full left-0 bg-white shadow-lg rounded-lg py-3 min-w-[220px] border border-ivory animate-fade-in">
                    <div className="px-4 pb-2 mb-2 border-b border-ivory">
                      <span className="text-xs uppercase tracking-wider text-charcoal/50">
                        {category.name}
                      </span>
                    </div>
                    {category.subcategories.map((sub) => (
                      <Link
                        key={sub.slug}
                        to={`/category/${category.slug}/${sub.slug}`}
                        className="block px-4 py-2 text-charcoal hover:bg-ivory hover:text-dusty-rose transition-colors"
                      >
                        {sub.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            <Link 
              to="/about" 
              className="px-4 py-2 text-charcoal hover:text-dusty-rose transition-colors font-medium"
            >
              About
            </Link>
            <Link 
              to="/resources" 
              className="px-4 py-2 text-charcoal hover:text-dusty-rose transition-colors font-medium"
            >
              Resources
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex justify-between items-center py-3">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-charcoal"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <button className="p-2 text-charcoal">
              <Search size={20} />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t border-ivory animate-fade-in">
            <div className="max-w-7xl mx-auto px-4 py-4">
              <Link to="/" className="block py-3 text-charcoal font-medium border-b border-ivory">
                Home
              </Link>
              {categories.map((category) => (
                <div key={category.id} className="border-b border-ivory">
                  <Link
                    to={`/category/${category.slug}`}
                    className="block py-3 text-charcoal font-medium"
                  >
                    {category.icon} {category.name}
                  </Link>
                  <div className="pl-6 pb-2">
                    {category.subcategories.map((sub) => (
                      <Link
                        key={sub.slug}
                        to={`/category/${category.slug}/${sub.slug}`}
                        className="block py-2 text-charcoal/70 text-sm"
                      >
                        {sub.name}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
              <Link to="/about" className="block py-3 text-charcoal font-medium border-b border-ivory">
                About
              </Link>
              <Link to="/resources" className="block py-3 text-charcoal font-medium border-b border-ivory">
                Resources
              </Link>
              <Link to="/start-here" className="block py-3 text-dusty-rose font-medium">
                Start Here →
              </Link>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;
