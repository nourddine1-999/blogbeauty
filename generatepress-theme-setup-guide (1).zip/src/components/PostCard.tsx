import { Link } from 'react-router-dom';
import { Clock, User, Bookmark } from 'lucide-react';
import { Post } from '../data/posts';
import { getCategoryBySlug } from '../data/categories';

interface PostCardProps {
  post: Post;
  variant?: 'default' | 'featured' | 'horizontal';
}

const PostCard = ({ post, variant = 'default' }: PostCardProps) => {
  const category = getCategoryBySlug(post.category);

  if (variant === 'horizontal') {
    return (
      <article className="group flex flex-col md:flex-row gap-6 bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
        <Link to={`/post/${post.slug}`} className="md:w-2/5 aspect-video md:aspect-auto">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </Link>
        <div className="flex-1 p-6 flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-3">
            <Link
              to={`/category/${post.category}`}
              className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full"
              style={{ backgroundColor: `${category?.color}20`, color: category?.color }}
            >
              {category?.name.split('&')[0].trim()}
            </Link>
          </div>
          <Link to={`/post/${post.slug}`}>
            <h3 className="font-playfair text-xl font-semibold text-charcoal mb-3 group-hover:text-dusty-rose transition-colors line-clamp-2">
              {post.title}
            </h3>
          </Link>
          <p className="text-charcoal/70 text-sm mb-4 line-clamp-2">
            {post.excerpt}
          </p>
          <div className="flex items-center gap-4 text-xs text-charcoal/50">
            <span className="flex items-center gap-1">
              <User size={12} />
              {post.author}
            </span>
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {post.readTime}
            </span>
          </div>
        </div>
      </article>
    );
  }

  if (variant === 'featured') {
    return (
      <article className="group relative h-[400px] rounded-xl overflow-hidden">
        <Link to={`/post/${post.slug}`}>
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/40 to-transparent" />
        </Link>
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <div className="flex items-center gap-3 mb-3">
            <Link
              to={`/category/${post.category}`}
              className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm"
            >
              {category?.name.split('&')[0].trim()}
            </Link>
          </div>
          <Link to={`/post/${post.slug}`}>
            <h3 className="font-playfair text-2xl font-semibold mb-3 group-hover:text-dusty-rose transition-colors">
              {post.title}
            </h3>
          </Link>
          <p className="text-white/80 text-sm mb-4 line-clamp-2">
            {post.excerpt}
          </p>
          <div className="flex items-center gap-4 text-xs text-white/60">
            <span className="flex items-center gap-1">
              <User size={12} />
              {post.author}
            </span>
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {post.readTime}
            </span>
          </div>
        </div>
        <button 
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-dusty-rose transition-colors"
          title="Save to Pinterest"
        >
          <Bookmark size={18} className="text-white" />
        </button>
      </article>
    );
  }

  return (
    <article className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <Link to={`/post/${post.slug}`} className="block aspect-[4/3] overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </Link>
      <div className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <Link
            to={`/category/${post.category}`}
            className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full"
            style={{ backgroundColor: `${category?.color}20`, color: category?.color }}
          >
            {category?.name.split('&')[0].trim()}
          </Link>
        </div>
        <Link to={`/post/${post.slug}`}>
          <h3 className="font-playfair text-lg font-semibold text-charcoal mb-2 group-hover:text-dusty-rose transition-colors line-clamp-2">
            {post.title}
          </h3>
        </Link>
        <p className="text-charcoal/70 text-sm mb-4 line-clamp-2">
          {post.excerpt}
        </p>
        <div className="flex items-center justify-between text-xs text-charcoal/50">
          <span className="flex items-center gap-1">
            <Clock size={12} />
            {post.readTime}
          </span>
          <button 
            className="flex items-center gap-1 hover:text-dusty-rose transition-colors"
            title="Save to Pinterest"
          >
            <Bookmark size={14} />
            Save
          </button>
        </div>
      </div>
    </article>
  );
};

export default PostCard;
