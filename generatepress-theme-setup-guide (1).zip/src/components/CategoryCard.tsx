import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Category } from '../data/categories';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard = ({ category }: CategoryCardProps) => {
  return (
    <Link
      to={`/category/${category.slug}`}
      className="group relative bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 border border-ivory overflow-hidden"
    >
      <div 
        className="absolute top-0 left-0 w-full h-1 transition-all duration-300 group-hover:h-2"
        style={{ backgroundColor: category.color }}
      />
      <div className="flex flex-col items-center text-center">
        <span className="text-4xl mb-4">{category.icon}</span>
        <h3 className="font-playfair text-lg font-semibold text-charcoal mb-2 group-hover:text-dusty-rose transition-colors">
          {category.name.split('&')[0].trim()}
        </h3>
        <p className="text-charcoal/60 text-sm mb-4 line-clamp-2">
          {category.description.slice(0, 80)}...
        </p>
        <span 
          className="inline-flex items-center gap-1 text-sm font-medium transition-colors"
          style={{ color: category.color }}
        >
          Explore
          <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
        </span>
      </div>
    </Link>
  );
};

export default CategoryCard;
