export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  category: string;
  subcategory: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
  tags: string[];
  featured?: boolean;
}

export const posts: Post[] = [
  // Home Decor Posts
  {
    id: '1',
    title: '15 Minimalist Living Room Ideas That Feel Warm and Inviting',
    slug: 'minimalist-living-room-ideas',
    excerpt: 'Discover how to create a minimalist living room that feels cozy, not cold. These design tips will help you declutter while maintaining warmth.',
    category: 'home-decor',
    subcategory: 'living-room',
    author: 'Emma Collins',
    date: '2024-01-15',
    readTime: '8 min',
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&q=80',
    tags: ['minimalist', 'living-room', 'cozy'],
    featured: true,
  },
  {
    id: '2',
    title: 'Budget-Friendly Bedroom Makeover: Transform Your Space for Under $200',
    slug: 'budget-bedroom-makeover',
    excerpt: 'You don\'t need a big budget to create a beautiful bedroom. Learn our favorite tricks for a stunning transformation.',
    category: 'home-decor',
    subcategory: 'bedroom',
    author: 'Emma Collins',
    date: '2024-01-12',
    readTime: '6 min',
    image: 'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=800&q=80',
    tags: ['budget-decor', 'bedroom', 'makeover'],
  },
  {
    id: '3',
    title: 'The Ultimate Home Organization Guide for Small Spaces',
    slug: 'home-organization-small-spaces',
    excerpt: 'Maximize every inch of your home with these clever organization solutions perfect for apartments and small homes.',
    category: 'home-decor',
    subcategory: 'organization',
    author: 'Emma Collins',
    date: '2024-01-10',
    readTime: '10 min',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
    tags: ['organization', 'small-spaces', 'rental-friendly'],
  },
  
  // Beauty Posts
  {
    id: '4',
    title: 'The Perfect 10-Step Korean Skincare Routine for Glowing Skin',
    slug: 'korean-skincare-routine',
    excerpt: 'Master the art of K-beauty with this comprehensive guide to building your perfect skincare routine.',
    category: 'beauty',
    subcategory: 'skincare',
    author: 'Sophia Lee',
    date: '2024-01-14',
    readTime: '12 min',
    image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=800&q=80',
    tags: ['skincare', 'k-beauty', 'glowup'],
    featured: true,
  },
  {
    id: '5',
    title: '20 Best Drugstore Makeup Products That Rival High-End Brands',
    slug: 'best-drugstore-makeup',
    excerpt: 'Save money without sacrificing quality. These affordable finds perform just as well as luxury alternatives.',
    category: 'beauty',
    subcategory: 'drugstore',
    author: 'Sophia Lee',
    date: '2024-01-11',
    readTime: '9 min',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&q=80',
    tags: ['drugstore', 'makeup', 'budget'],
  },
  {
    id: '6',
    title: 'Clean Beauty 101: How to Read Ingredient Labels',
    slug: 'clean-beauty-ingredient-labels',
    excerpt: 'Navigate the world of clean beauty with confidence. Learn which ingredients to embrace and which to avoid.',
    category: 'beauty',
    subcategory: 'clean-beauty',
    author: 'Sophia Lee',
    date: '2024-01-08',
    readTime: '7 min',
    image: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=800&q=80',
    tags: ['clean-beauty', 'skincare', 'natural'],
  },

  // Fashion Posts
  {
    id: '7',
    title: 'Build a Capsule Wardrobe: 30 Pieces, Endless Outfits',
    slug: 'capsule-wardrobe-guide',
    excerpt: 'Simplify your closet and elevate your style with this complete guide to building a functional capsule wardrobe.',
    category: 'fashion',
    subcategory: 'capsule-wardrobe',
    author: 'Mia Rodriguez',
    date: '2024-01-13',
    readTime: '11 min',
    image: 'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&q=80',
    tags: ['capsule', 'wardrobe', 'minimalist'],
    featured: true,
  },
  {
    id: '8',
    title: 'Spring 2024 Fashion Trends: What to Wear This Season',
    slug: 'spring-2024-fashion-trends',
    excerpt: 'From soft pastels to bold statements, discover the top trends that will define spring fashion this year.',
    category: 'fashion',
    subcategory: 'seasonal',
    author: 'Mia Rodriguez',
    date: '2024-01-09',
    readTime: '8 min',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&q=80',
    tags: ['trends', 'spring', 'ootd'],
  },
  {
    id: '9',
    title: '10 Chic Outfit Ideas for Work That Are Actually Comfortable',
    slug: 'work-outfit-ideas',
    excerpt: 'Look professional without sacrificing comfort. These work outfits will take you from meetings to happy hour.',
    category: 'fashion',
    subcategory: 'outfits',
    author: 'Mia Rodriguez',
    date: '2024-01-06',
    readTime: '6 min',
    image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=800&q=80',
    tags: ['workwear', 'ootd', 'office'],
  },

  // Wellness Posts
  {
    id: '10',
    title: 'The Ultimate Morning Routine for Productivity and Peace',
    slug: 'ultimate-morning-routine',
    excerpt: 'Start your day with intention. This morning routine combines productivity hacks with mindful practices.',
    category: 'wellness',
    subcategory: 'routines',
    author: 'Ava Chen',
    date: '2024-01-14',
    readTime: '9 min',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&q=80',
    tags: ['morningroutine', 'selfcare', 'productivity'],
    featured: true,
  },
  {
    id: '11',
    title: 'Journaling Prompts for Self-Discovery and Mental Clarity',
    slug: 'journaling-prompts-self-discovery',
    excerpt: 'Unlock deeper self-awareness with these thought-provoking journal prompts designed for personal growth.',
    category: 'wellness',
    subcategory: 'journaling',
    author: 'Ava Chen',
    date: '2024-01-07',
    readTime: '7 min',
    image: 'https://images.unsplash.com/photo-1517842645767-c639042777db?w=800&q=80',
    tags: ['journaling', 'selfcare', 'mentalhealth'],
  },
  {
    id: '12',
    title: '15-Minute Mindfulness Exercises for Busy Days',
    slug: 'mindfulness-exercises-busy-days',
    excerpt: 'No time for meditation? These quick mindfulness exercises fit seamlessly into your hectic schedule.',
    category: 'wellness',
    subcategory: 'mindfulness',
    author: 'Ava Chen',
    date: '2024-01-05',
    readTime: '5 min',
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=80',
    tags: ['mindfulness', 'meditation', 'selfcare'],
  },

  // Finance Posts
  {
    id: '13',
    title: 'The 50/30/20 Budget Rule: A Beginner\'s Complete Guide',
    slug: '50-30-20-budget-rule',
    excerpt: 'Master your money with this simple yet effective budgeting framework that actually works.',
    category: 'finance',
    subcategory: 'budgeting',
    author: 'Olivia Harper',
    date: '2024-01-13',
    readTime: '10 min',
    image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80',
    tags: ['budgeting', 'savingmoney', 'finance'],
    featured: true,
  },
  {
    id: '14',
    title: '25 Creative Side Hustles You Can Start This Weekend',
    slug: 'creative-side-hustles',
    excerpt: 'Boost your income with these flexible side hustle ideas perfect for anyone looking to earn extra money.',
    category: 'finance',
    subcategory: 'side-hustles',
    author: 'Olivia Harper',
    date: '2024-01-10',
    readTime: '12 min',
    image: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=800&q=80',
    tags: ['sidehustle', 'income', 'money'],
  },
  {
    id: '15',
    title: 'How I Paid Off $30,000 in Debt in 18 Months',
    slug: 'debt-payoff-journey',
    excerpt: 'My personal debt-free journey with actionable strategies you can apply to your own financial situation.',
    category: 'finance',
    subcategory: 'debt',
    author: 'Olivia Harper',
    date: '2024-01-04',
    readTime: '14 min',
    image: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=800&q=80',
    tags: ['debtfree', 'money', 'savingmoney'],
  },

  // DIY Posts
  {
    id: '16',
    title: '10 Weekend DIY Projects That Will Transform Your Home',
    slug: 'weekend-diy-projects',
    excerpt: 'Tackle these satisfying DIY projects over the weekend and see instant results in your home.',
    category: 'diy',
    subcategory: 'home-projects',
    author: 'Luna Martinez',
    date: '2024-01-12',
    readTime: '11 min',
    image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800&q=80',
    tags: ['homediy', 'weekend', 'projects'],
    featured: true,
  },
  {
    id: '17',
    title: 'Thrift Store Finds: How to Spot Hidden Gems',
    slug: 'thrift-store-finds',
    excerpt: 'Learn the art of thrifting with these expert tips for finding quality pieces at secondhand stores.',
    category: 'diy',
    subcategory: 'upcycling',
    author: 'Luna Martinez',
    date: '2024-01-08',
    readTime: '8 min',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80',
    tags: ['thrifted', 'upcycle', 'sustainable'],
  },
  {
    id: '18',
    title: 'DIY Wall Art Ideas Using Items You Already Have',
    slug: 'diy-wall-art-ideas',
    excerpt: 'Create stunning wall art without spending a fortune. These creative ideas use everyday materials.',
    category: 'diy',
    subcategory: 'decor',
    author: 'Luna Martinez',
    date: '2024-01-03',
    readTime: '7 min',
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e35a6?w=800&q=80',
    tags: ['crafts', 'homediy', 'budget'],
  },
];

export const getFeaturedPosts = (): Post[] => {
  return posts.filter((post) => post.featured);
};

export const getPostsByCategory = (categorySlug: string): Post[] => {
  return posts.filter((post) => post.category === categorySlug);
};

export const getLatestPosts = (count: number = 6): Post[] => {
  return [...posts]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, count);
};

export const getPostBySlug = (slug: string): Post | undefined => {
  return posts.find((post) => post.slug === slug);
};
