export interface Subcategory {
  name: string;
  slug: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  subcategories: Subcategory[];
}

export const categories: Category[] = [
  {
    id: 'home-decor',
    name: 'Home Decor & Interiors',
    slug: 'home-decor',
    description: 'Transform your space with inspiring interior design ideas, organization tips, and budget-friendly decorating solutions.',
    icon: '🏠',
    color: '#8B7355',
    subcategories: [
      { name: 'Living Room Ideas', slug: 'living-room' },
      { name: 'Bedroom Styling', slug: 'bedroom' },
      { name: 'Home Organization', slug: 'organization' },
      { name: 'Budget Decorating', slug: 'budget-decor' },
      { name: 'Seasonal Decor', slug: 'seasonal' },
    ],
  },
  {
    id: 'beauty',
    name: 'Beauty & Skincare',
    slug: 'beauty',
    description: 'Discover skincare routines, makeup tutorials, and clean beauty products that help you glow from the inside out.',
    icon: '💄',
    color: '#E8B4B8',
    subcategories: [
      { name: 'Skincare Routines', slug: 'skincare' },
      { name: 'Makeup Tutorials', slug: 'makeup' },
      { name: 'Hair Care', slug: 'hair' },
      { name: 'Clean Beauty', slug: 'clean-beauty' },
      { name: 'Budget Beauty', slug: 'drugstore' },
    ],
  },
  {
    id: 'fashion',
    name: "Women's Fashion",
    slug: 'fashion',
    description: 'Outfit inspiration, capsule wardrobe guides, and seasonal style tips to elevate your everyday look.',
    icon: '👗',
    color: '#9B8AA5',
    subcategories: [
      { name: 'Outfit Ideas', slug: 'outfits' },
      { name: 'Capsule Wardrobe', slug: 'capsule-wardrobe' },
      { name: 'Seasonal Style', slug: 'seasonal' },
      { name: 'Fashion on a Budget', slug: 'budget-fashion' },
      { name: 'Accessories', slug: 'accessories' },
    ],
  },
  {
    id: 'wellness',
    name: 'Self-Care & Wellness',
    slug: 'wellness',
    description: 'Nurture your mind, body, and soul with wellness routines, mindfulness practices, and self-care rituals.',
    icon: '🧘',
    color: '#7FB3A8',
    subcategories: [
      { name: 'Mental Health', slug: 'mental-health' },
      { name: 'Morning & Night Routines', slug: 'routines' },
      { name: 'Mindfulness', slug: 'mindfulness' },
      { name: 'Journaling & Affirmations', slug: 'journaling' },
      { name: 'Fitness & Movement', slug: 'fitness' },
    ],
  },
  {
    id: 'finance',
    name: 'Personal Finance',
    slug: 'finance',
    description: 'Take control of your money with budgeting tips, saving strategies, and financial wellness guidance.',
    icon: '💵',
    color: '#6B8E7A',
    subcategories: [
      { name: 'Budgeting Tips', slug: 'budgeting' },
      { name: 'Saving Money', slug: 'saving' },
      { name: 'Side Hustles', slug: 'side-hustles' },
      { name: 'Debt Payoff', slug: 'debt' },
      { name: 'Money Mindset', slug: 'money-mindset' },
    ],
  },
  {
    id: 'diy',
    name: 'DIY & Crafts',
    slug: 'diy',
    description: 'Get creative with home DIY projects, upcycling ideas, and budget-friendly craft tutorials.',
    icon: '🎨',
    color: '#D4A574',
    subcategories: [
      { name: 'Home DIY Projects', slug: 'home-projects' },
      { name: 'DIY Decor', slug: 'decor' },
      { name: 'Upcycling & Thrifting', slug: 'upcycling' },
      { name: 'Seasonal Crafts', slug: 'seasonal-crafts' },
      { name: 'Budget DIY', slug: 'budget' },
    ],
  },
];

export const getCategoryBySlug = (slug: string): Category | undefined => {
  return categories.find((cat) => cat.slug === slug);
};
